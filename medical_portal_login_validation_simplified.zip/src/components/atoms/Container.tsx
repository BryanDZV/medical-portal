import React from "react";

type ContainerProps = {
    children: React.ReactNode;
    className?: string;
};

export function Container({
    children,
    className = "",
}: ContainerProps) {
    return (
        <div
            className={`
                w-full
                max-w-7xl
                mx-auto
                px-4
                md:px-6
                lg:px-8
                ${className}
            `}
        >
            {children}
        </div>
    );
}