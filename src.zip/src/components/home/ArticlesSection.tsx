import { mockSpecialtyServices } from "../../data/mockSpecialtyServices";

export function ArticlesSection() {
  return (
    <section id="services" className="bg-white px-6 py-20">
      <div className="mx-auto max-w-6xl">
        <p className="text-sm font-semibold uppercase tracking-[0.18em] text-blue-600">
          Nuestros servicios
        </p>

        <h2 className="mt-3 text-4xl font-bold text-slate-900">
          Especialidades médicas disponibles
        </h2>

        <p className="mt-4 max-w-3xl text-lg leading-8 text-slate-600">
          Ponemos a tu disposición distintas áreas de atención sanitaria para
          ofrecer un seguimiento más completo y especializado. Contamos con
          varios centros médicos.
        </p>

        <div className="mt-10 overflow-hidden">
          <div className="flex w-max animate-specialties-scroll gap-6 pt-0 mt-5">
            {[...mockSpecialtyServices, ...mockSpecialtyServices].map(
              (service, index) => (
                <article
                  key={`${service.specialty}-${index}`}
                  className="w-[320px] shrink-0 rounded-2xl border border-slate-200 bg-white p-6 transition hover:-translate-y-0.5 hover:shadow-sm"
                >
                  <h3 className="text-xl font-semibold text-slate-900">
                    {service.specialty}
                  </h3>

                  <p className="mt-3 leading-7 text-slate-600">
                    {service.description}
                  </p>
                </article>
              ),
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
